package com.example.flutter_ecommerce_website_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
